
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

/**
 *\brief Muestra el menú de opciones.
 * \param no recibe ningún parámetro
 * \return  La opción elegida.
 */

char menu () {

    char opcion;

    printf("\n\n---Menu---\n\n");
    printf("a- Suma \n");
    printf("b- Resta \n");
    printf("c- multiplicacion\n");
    printf("d- Division \n");
    printf("e- Factorial \n");
    printf("f- Salir! \n");
    fpurge(stdin);
    scanf("%c", &opcion);

    return opcion;
}

/**
 *  \brief Muestra un mensaje, pide un número al usuario y lo muestra.
 * \param El mensaje a ser mostrado
 * \return Devuelve el numero ingresado por el usuario.
 */

int pedirNumero (char mensaje [ ])
{
    int num;

    printf("%s",mensaje);
    scanf("%d",&num);
    printf("El numero ingresado es: %d", num);
    return num;
}

/**
 *  \brief recibe dos numeros y los suma.
 * \param los dos números a sumar.
 * \return Devuelve la suma de dichos numeros.
 */

int suma (int a, int b)
{
     int rta;

     rta = a + b;
     return rta;
}

/**
 *  \brief recibe dos numeros y los resta.
 * \param los dos números a restar
 * \return Devuelve la resta de dichos numeros.
 */

int resta (int a, int b)
{
    int rta;

    rta = a-b;
    return rta;
}
/**
 *  \brief recibe dos numeros y los multiplica.
 * \param los dos números a multiplicar.
 * \return Devuelve el producto de dichos numeros.
 */
int multiplicacion (int a, int b)
{
    int rta;

    rta = a*b;
    return rta;
}

/**
 *  \brief recibe dos numeros y los divide.
 * \param los dos números a dividir.
 * \return Devuelve la división de dichos números.
 */

int division (int a, int b)
{
    int rta;

    rta = a/b;
    return rta;
}

/**
 *  \brief Recibe un número y lo factorea.
 * \param El número a factorizar.
 * \return Devuelve el factorial de dicho número.
 */
int factorial( int x)
{
    int fact = 1;

        if( x > 1)
        {
            fact = x * factorial( x-1);
        }

    return fact;
}
