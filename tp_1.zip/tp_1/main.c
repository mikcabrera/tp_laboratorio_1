
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

int num1;
int num2;


int main()
{

    int resultado;
    int resultadoF;
    char salida ='s';

        num1 = pedirNumero("Ingrese el primer operando: ");
        num2 = pedirNumero("\n Ingrese el segundo operando: ");

 do {


    switch (menu()) {

        case 'a':
                  resultado = suma(num1, num2);
                  printf("El resultado de %d + %d es %d",num1,num2,resultado);
                  break;

        case 'b':
                  resultado = resta(num1, num2);
                  printf("El resultado de  %d - %d es %d",num1,num2,resultado);
                  break;

        case 'c':
                  resultado = multiplicacion(num1, num2);
                  printf("El resultado de  %d * %d es %d",num1,num2,resultado);
                  break;

        case 'd':

                  resultado = division(num1,num2);
                  printf("El resultado de  %d / %d es %d",num1,num2,resultado);

                  break;

        case 'e': resultado = factorial(num1);
                  resultadoF = factorial(num2);
                  printf("Usted eligio la opcion E Factorial :\n !%d = %d\n !%d = %d ",num1,resultado,num2,resultadoF);
                  break;

        case 'f':
                  printf("Confirma salida N/S?: \n");
                  fpurge(stdin);
                  salida=getchar();
                  break;

        default: printf("Salida invalida \n");
                 break;

                 system("pause");

    }


 }  while(salida=='n' || salida=='N');


}


