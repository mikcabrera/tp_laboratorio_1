

int pedirNumero (char mensaje [ ]);
int suma (int a, int b);
int resta (int a, int b);
int multiplicacion (int a, int b);
int division (int a, int b);
int factorial( int x);
char menu();

