#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 6
#include "arrayemployees.h"

int main()
{
        char respuesta = 'n';
        Employee listaEmpleados [TAM];
        int id = 1000;
        int carga = 0;

        initEmployees(listaEmpleados,TAM);
        //id = id + hardcodearEmployees(listaEmpleados, TAM, 4);


    do {
        switch(menu()) {

        case 1:
                if (addEmployee (listaEmpleados,TAM,id))
                {id++;
                carga = 1;
                }
        break;

        case 2:
                if(carga !=1)
                {
                printf("No se cargo ningun empleado.");
                }
                else {
                      changeEmployee (listaEmpleados, TAM);
                     }

        break;

         case 3:
                if(carga !=1)
                {
                printf("No se cargo ningun empleado");
                }
                else {
                      removeEmployee(listaEmpleados, TAM);
                     }
        break;

         case 4:
                if(carga !=1)
                {
                printf("No se cargo ningun empleado");
                }
                else {
                      informes(listaEmpleados,TAM);
                     }

        break;

         case 5:    printf("Confirma salida? \n\n");
                    fpurge(stdin);
                    respuesta = getchar();
        break;

         default: printf("No es una opcion valida. \n");
                  system("pause");
            break;

        }

    } while(respuesta =='n');


return 0;
}
