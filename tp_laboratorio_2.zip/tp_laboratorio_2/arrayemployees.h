#ifndef ARRAYEMPLOYEES_H_INCLUDED
#define ARRAYEMPLOYEES_H_INCLUDED

typedef struct
{
    int id;
    char name[51];
    char lastName[51];
    float salary;
    int sector;
    int isEmpty;

}Employee;

#endif // ARRAYEMPLOYEES_H_INCLUDED
int menu ();

int menuInformes();

void initEmployees(Employee listaEmpleados[], int tam);


void printEmployee (Employee x, int tam);
void printEmployees (Employee listaEmpleados[], int tam);

int findEmployeeById (int id, Employee listaEmpleados[], int tam);
int findVoid (Employee listaEmpleados[], int tam); //retorna -1 si no hay lugar.
Employee newEmployee (int id,char name[], char lastName[],  float salary, int sector);
int addEmployee (Employee listaEmpleados[], int tam, int id);
int changeEmployee (Employee listaEmpleados[], int tam);
int removeEmployee (Employee listaEmpleados[], int tam);
int sortEmployeesBySector(Employee listaEmpleados[], int tam, int order);

void promSalaryEmployee(Employee listaEmpleados[], int tam);
void informes(Employee listaEmpleados[], int tam);
void mediaSalary(Employee listaEmpleados[], int tam);
int hardcodearEmployees(Employee listaEmpleados[], int tam,int cantidad);

