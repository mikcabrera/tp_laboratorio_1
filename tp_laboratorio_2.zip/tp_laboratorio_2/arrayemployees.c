
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arrayemployees.h"

/**
 *\brief Muestra el men� de opciones.
 * \param no recibe ning�n par�metro
 * \return  La opci�n elegida.
 */

int menu ()
{
    int opcion;

    printf("\n\n ---Menu de opciones---\n\n");
    printf("1- Dar de alta \n");
    printf("2- Modificar empleado/a \n");
    printf("3- Dar de baja empleado/a \n");
    printf("4- Informes \n ");
    printf("5- Salir \n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);
    system("clear");

return opcion;
}

/**
 *\brief Muestra el sub men� de opciones.
 * \param no recibe ning�n par�metro
 * \return  La opci�n elegida.
 */
int menuInformes()
{
    int opcion;

    printf("\n\n ---Menu Informes---\n\n");
    printf("1- Ordenar por sector de manera ascendente. \n");
    printf("2- Ordenar por sector de manera descendente. \n");
    printf("3- Calcular el total y promedio de los salarios. \n");
    printf("4- El total de los empleados y empleadas que superan la media salarial. \n");
    printf("5- Salir \n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);
    system("clear");

return opcion;
}


/**
 *\brief Inicializa los empleados en 1 (TRUE), indicando que el estado de la posici�n es vac�a.
 * \param recibe el array de empleados y su tama�o.
 * \return no retorna nada.
 */

void initEmployees( Employee listaEmpleados[], int tam)
{
    for(int i=0; i<tam; i++)
    {
            listaEmpleados[i].isEmpty = 1;
    }
}

/**
 *\brief Imprime un empleado/a.
 * \param recibe el array de empleados y su tama�o.
 * \return no retorna nada.
 */

void printEmployee (Employee x, int tam)
{
    printf("%d    %s        %s             %.2f      %d   ", x.id,  x.name, x.lastName, x.salary, x.sector);
    printf("\n");


}

/**
 *\brief Imprime la lista de empleados y empleadas.
 * \param recibe el array de empleados y su tama�o.
 * \return no retorna nada.
 */

void printEmployees (Employee listaEmpleados[], int tam)
{

    int flag = 0;
    system("clear");
    printf("    Lista de empleados    \n\n");
    printf("Id     Nombre        Apellido   Salario   Sector \n\n");

    for(int i=0; i<tam; i++)
        {
            if(listaEmpleados[i].isEmpty==0)
            {
                printEmployee(listaEmpleados[i],tam);
                printf("\n");
                flag = 1;
            }
        }

    if(flag==0)
    {
    system("clear");
    printf("\n    No hay alumnos que mostrar    ");
    }

    printf("\n\n");
}

/**
 *\brief Retorna el indice de la primera posici�n vac�a. Si no encuentra ninguna retorna -1.
 * \param recibe el array de empleados y su tama�o.
 * \return retorna el �ndice.
 */

int findVoid (Employee listaEmpleados[], int tam)
{
    int indice= -1;

    for(int i=0; i<tam; i++)
    {
        if(listaEmpleados[i].isEmpty == 1)
        {
            indice =i;
            break;
        }
    }

return indice;
}

/**
 *\brief Retorna el indice del empleado/a con el ID que le pasamos. Si no existe retorna -1.
 * \param recibe un id y el array de empleados y su tama�o.
 * \return retorna el �ndice.
 */

int findEmployeeById (int id, Employee listaEmpleados[], int tam)
{
    int indice = -1;

    for (int i=0; i<tam; i++)
        {
            if(listaEmpleados[i].isEmpty == 0 && listaEmpleados[i].id == id)
                 {
                    indice = i;
                    break;
                 }
        }

 return indice;
}

/**
 *\brief Carga por completo un empleado/a en una posici�n nueva del array.
 * \param recibe los datos del empleado (id, nombre, apellido, salaio y sector)
 * \return retorna el paquete de un empleado cargado.
 */

Employee newEmployee (int id,char name[], char lastName[],  float salary, int sector)
{
    Employee newEmployee;

    newEmployee.id = id;
    strcpy(newEmployee.name, name);
    strcpy(newEmployee.lastName, lastName);
    newEmployee.salary = salary;
    newEmployee.sector =sector;
    newEmployee.isEmpty = 0;

   return newEmployee;
}

/**
 *\brief Da el alta a un empleado o una empleada.
 * \param recibe el array de empleados y el id generado automaticamente.
 * \return 1 si el alta fue exitosa y 0 si ni lo fue.
 */

int addEmployee (Employee listaEmpleados[], int tam, int id)
{
    int ok = 0;
    int indice;
    char name[51];
    char lastName[51];
    float salary;
    int sector;


    system("clear");
    printf("**** Alta Alumno ****\n\n");

    indice = findVoid(listaEmpleados, tam);


    if (indice == -1 )
        {
            printf("No hay lugar para agregar un empleado.\n");
            system("pause");
        }

     else {
            printf("Ingrese nombre: ");
            fpurge(stdin);
            gets(name);

            printf("Ingrese apellido: ");
            fpurge(stdin);
            gets(lastName);

            printf("Ingrese salario: ");
            scanf("%f", &salary);


            printf("Ingrese sector: ");
            scanf("%d", &sector);

            listaEmpleados[indice] = newEmployee(id,name,lastName,salary,sector);

            printf("\n\n Alta exitosa\n\n");
            ok = 1;


     }

return ok;
}

/**
 *\brief Realiza modificaciones sobre un empleado o una empleada.
 * \param recibe el array de empleados y su tama�o.
 * \return 1 si el proceso fue exitoso y 0 si ni lo fue.
 */

int changeEmployee (Employee listaEmpleados[], int tam)
{
    int ok = 0 ;
    int id;
    int indice;
    int opcion;
    char nombre[51];
    char apellido[51];
    float salario;
    int sector;

    system("clear");
    printf("  **** Realizar modificaciones ****\n");

    printf("Ingrese el id: ");
    scanf("%d", &id);

    indice = findEmployeeById (id,listaEmpleados,tam);

    if(indice == -1 )

        {
            printf("No encontramos ese numero de id. Verifique.");
            system("pause");
        }

    else
        {
            printf("Empleado: ");
            printEmployee(listaEmpleados[indice],tam);

            printf(" \n Ingrese opcion: \n");
            printf("1- Modificar nombre del empleado \n");
            printf("2- Mofificar apellido del empleado: \n");
            printf("3- Modificar salario \n");
            printf("4- Modificar sector \n");
            scanf("%d", &opcion);
            system ("clear");

            switch (opcion) {

            case 1:
                    printf("Ingrese nuevo dato (nombre): ");
                    fpurge(stdin);
                    gets(nombre);
                    strcpy(listaEmpleados[indice].name, nombre);

                    printf("\nActualizacion\n");
                    printf("Operacion exitosa\n");
                    printEmployee(listaEmpleados[indice],tam);

                    ok=1;
            break;

            case 2:
                    printf("Ingrese nuevo dato (apellido): ");
                    fpurge(stdin);
                    gets(apellido);
                    strcpy(listaEmpleados[indice].lastName, apellido);

                    printf("\nActualizacion\n");
                     printf("Operacion exitosa\n");
                    printEmployee(listaEmpleados[indice],tam);

                    ok=1;
            break;

            case 3:
                    printf("Ingrese nuevo dato (salario): ");
                    scanf("%f", &salario);
                    listaEmpleados[indice].salary = salario;


                    printf("\nActualizacion\n");
                    printf("Operacion exitosa\n");
                    printEmployee(listaEmpleados[indice],tam);


                    ok=1;
            break;

            case 4:
                    printf("Ingrese nuevo dato (sector): ");
                    scanf("%d", &sector);
                    listaEmpleados[indice].sector = sector;

                    printf("\nActualizacion\n");
                    printf("Operacion exitosa\n");
                    printEmployee(listaEmpleados[indice],tam);

                    ok=1;
            break;

            default: printf("Opcion invalida");
                     system("pause");
            }
        }

return ok;
}

/**
 *\brief Da de baja a un empleado o una empleada.
 * \param recibe el array de empleados y su tama�o.
 * \return 1 si la baja fue exitosa y 0 si ni lo fue.
 */


int removeEmployee (Employee listaEmpleados[], int tam)
{
    int ok=0;
    int id;
    int indice;
    char rta;

    system("clear");
    printf("---- Baja Empleado ----\n\n");

    printf("Ingrese el Id del empleado a eliminar ");
    scanf("%d", &id);

    indice = findEmployeeById (id,listaEmpleados,tam);

    if(indice != -1)
    {
        printEmployee(listaEmpleados[indice] ,tam);

        printf("Confirma eliminacion?: ");
        fpurge(stdin);
        rta= getchar();

    if(rta == 's' )
    {
        listaEmpleados[indice].isEmpty = 1;
        printf("Eliminacion exitosa.");
        ok=1;
    }
    else
        {
            printf("Operacion anulada.");
        }
    system("pause");
    }

    else  {

        printf("No existe empleado.");
        system("pause");
 }

return ok;
}
/**
 *\brief Sub-men� de opciones para los informes.
 * \param recibe el array de empleados y su tama�o.
 * \return no retorna nada.
 */


void informes(Employee listaEmpleados[], int tam)
{
    char salir = 'n';

    system("clear");
    printf("Menu informes \n\n");

    do
    {
        switch( menuInformes())
        {
        case 1:
            sortEmployeesBySector(listaEmpleados,tam,1);
            printEmployees (listaEmpleados,tam);
            break;

        case 2:
           sortEmployeesBySector(listaEmpleados,tam,0);
           printEmployees (listaEmpleados,tam);
            break;

        case 3:

           promSalaryEmployee(listaEmpleados,tam);

            break;


        case 4:
            mediaSalary(listaEmpleados,tam);

            break;

        case 5:
            printf("Confirma salir?:");
            fflush(stdin);
            salir = getchar();
            break;


        default:
            printf("\nOpcion invalida!\n\n");
        }
        system("pause");
    }
    while(salir == 'n');
}

/**
 *\brief Organiza de manera ascendente y descendente por sector el array.
 * \param recibe el array de empleados y el orden en el que se desea realizar la operaci�n.
 * \return 0 si el ata fue exitosa y -1 si ni lo fue.
 */


int sortEmployeesBySector(Employee listaEmpleados[], int tam, int order)
{
    int ok = -1;

    Employee listaAux;
    int swap = 0;

    for(int i=0; i<tam - 1; i++)
    {
        for (int j= i+1; j<tam; j++)
        {
            if(listaEmpleados[i].sector < listaEmpleados[j].sector && listaEmpleados[i].isEmpty == 0 && listaEmpleados[j].isEmpty == 0 && order == 0)
            {
                swap = 1;
                ok = 0;
            }

            else if(listaEmpleados[i].sector > listaEmpleados[j].sector && listaEmpleados[i].isEmpty == 0 && listaEmpleados[j].isEmpty == 0 && order == 1)
                {
                swap = 1;
                ok=0;
                }

          if(swap)
             {
                listaAux = listaEmpleados[i];
                listaEmpleados[i] = listaEmpleados[j];
                listaEmpleados[j] = listaAux;

                ok = 0;
                swap = 0;
            }
        }
    }
return ok;
}
/**
 *\brief Muestra el promedio y el total de los sueldos de los empleados y empleadas.
 * \param recibe el array de empleados y su tama�o.
 * \return no retorna nada.
 */


void promSalaryEmployee(Employee listaEmpleados[], int tam)
{
    float acuSalary = 0;
    float promedio;
    int cont = 0;

    for(int i=0; i<tam; i++)
    {
        if(listaEmpleados[i].isEmpty == 0 && tam > 2)
        {
            acuSalary = acuSalary+ listaEmpleados[i].salary;
            cont++;
        }
    }

    promedio = (float) acuSalary /cont;

    printf("El total de los sueldos es: %.2f \n\n", acuSalary);
    printf("El promedio de los sueldos es: %.2f", promedio);

}
/**
 *\brief Muestra la media salarial.
 * \param recibe el array de empleados y su tama�o.
 * \return no retorna nada.
 */


void mediaSalary(Employee listaEmpleados[], int tam)
{
    float acuSalary = 0;
    float promedio;
    int cont = 0;
    int contMedia = 0;


    for(int i=0; i<tam; i++)
    {
        if(listaEmpleados[i].isEmpty == 0)
        {
            acuSalary = acuSalary+ listaEmpleados[i].salary;
            cont++;
        }
        promedio = (float) acuSalary /cont;

        if(listaEmpleados[i].isEmpty == 0 &&  listaEmpleados[i].salary > promedio )
        {
            contMedia++;
        }
    }

printf("Los empleados que superan la media salarial son: %d", contMedia);

}


/**
 *\brief Harcodea los empleads para poder hacer pruebas.
 * \param recibe el array de empleados y la cantidad de empleados para hardcodear.
 * \return 1 si el ata fue exitosa y 0 si ni lo fue.
 */

int hardcodearEmployees(Employee listaEmpleados[], int tam,int cantidad)
{
    int cont = 0;

    Employee listaAuxiliar[]=
    {

        { 1000, "Maria", "Suarez",200,5,0},
        { 1001, "Luis", "Perez",300,4,0},
        { 1002, "Carolina", "Cachamai",300,5,0},
        { 1003, "Hector", "Vinito",200,4,0},
        { 1004, "Pablo", "Jouala",500,6,0},
        { 1005, "Alejandro", "Anchez",500,6,0}

    };

    if( cantidad <= tam && cantidad < 6)
    {
        for( int i=0; i < cantidad; i++)
        {
            listaEmpleados[i] = listaAuxiliar[i];
            cont++;
        }
    }
    return cont;
}

